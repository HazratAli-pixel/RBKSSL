.custom - control {
		position: relative;display: -webkit - inline - box;display: -webkit - inline - flex;display: -ms - inline - flexbox;display: inline - flex;min - height: 1.5 rem;padding - left: 1.5 rem;margin - right: 1 rem;cursor: pointer
	}.custom - control - input {
		position: absolute;z - index: -1;opacity: 0
	}.custom - control - input: checked~.custom - control - indicator {
		color: #fff;background - color: #0275d8}.custom-control-input:focus~.custom-control-indicator{-webkit-box-shadow:0 0 0 1px # fff,
		0 0 0 3 px #0275d8;box-shadow:0 0 0 1px # fff,
		0 0 0 3 px #0275d8}.custom-control-input:active~.custom-control-indicator{color:# fff;background - color: #8fcafe}.custom-control-input:disabled~.custom-control-indicator{cursor:not-allowed;background-color:# eceeef
	}.custom - control - input: disabled~.custom - control - description {
		color: #636c72;cursor:not-allowed}.custom-control-indicator{position:absolute;top:.25rem;left:0;display:block;width:1rem;height:1rem;pointer-events:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:# ddd;background - repeat: no - repeat;background - position: center center; - webkit - background - size: 50 % 50 % ;background - size: 50 % 50 %
	}.custom - checkbox.custom - control - indicator {
		border - radius: .25 rem
	}.custom - checkbox.custom - control - input: checked~.custom - control - indicator {
		background - image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3E%3Cpath fill='%23fff' d='M6.564.75l-3.59 3.612-1.538-1.55L0 4.26 2.974 7.25 8 2.193z'/%3E%3C/svg%3E")
	}.custom - checkbox.custom - control - input: indeterminate~.custom - control - indicator {
		background - color: #0275d8;background-image:url("data:image/svg+xml;charset= utf8, % 3 Csvg xmlns = 'http://www.w3.org/2000/svg'
		viewBox = '0 0 4 4' % 3 E % 3 Cpath stroke = '%23fff'
		d = 'M0 2h4' / % 3 E % 3 C / svg % 3 E ")}